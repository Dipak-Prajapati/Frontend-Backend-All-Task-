package com.dips.service;

import com.dips.dao.AddressDao;
import com.dips.dao.AddressDaoImpl;
import com.dips.pojo.AddressModel;

public class AddressServiceImpl implements AddressService{

	@Override
	public int insertAddress(AddressModel addressPojo) {
		// TODO Auto-generated method stub
		AddressDao addressDao = new AddressDaoImpl();
		
		
		return addressDao.insertAddress(addressPojo);
	}

}
