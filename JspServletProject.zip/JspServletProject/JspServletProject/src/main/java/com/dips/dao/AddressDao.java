package com.dips.dao;

import java.util.List;

import com.dips.pojo.AddressModel;

public interface AddressDao {
	
	public int insertAddress(AddressModel addressPojo);
	
	public List<Object> getaddress(AddressModel addressPojo);

}
