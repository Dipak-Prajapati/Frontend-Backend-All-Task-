package com.dips.pojo;

import java.util.Arrays;

public class AddressModel {

	public String buttonvalue;
	public String Email;
	public String[] address;
	public String[] city;
	public String[] country;
	public String[] state;
	public String id;
	
	
}
