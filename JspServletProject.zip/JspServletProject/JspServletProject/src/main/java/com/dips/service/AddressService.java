package com.dips.service;

import com.dips.pojo.AddressModel;

public interface AddressService {
	
	public int insertAddress(AddressModel addressPojo);

}
