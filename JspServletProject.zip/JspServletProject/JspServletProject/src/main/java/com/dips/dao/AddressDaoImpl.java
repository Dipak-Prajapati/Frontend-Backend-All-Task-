package com.dips.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dips.pojo.AddressModel;
import com.dips.singleton.DbConnection;

public class AddressDaoImpl implements AddressDao {


	Connection con;
	ResultSet result;
	PreparedStatement ps;
	DbConnection dbInstance;

	public AddressDaoImpl() {
		System.out.println("Hello Constructor from Dao");
		dbInstance = DbConnection.getInstance("jdbc:mysql://localhost:", "3306", "root", "password");
		System.out.println(dbInstance);
		try {
			con = dbInstance.Connect("jspservlet");
			System.out.println("Database name passed" + con);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println("\n Failed To Connnect DB " + e);
		}
	}
	
	@Override
	public int insertAddress(AddressModel addressPojo) {
		// TODO Auto-generated method stub
		int recordCounter=0;
		List<Object> employee = new ArrayList<Object>();
		employee = getaddress(addressPojo);
		int index = 0;
		while (employee.size() > index) {
			try {
				//int lastelement = addinsertid(addressPojo);
				//System.out.println(lastelement + "Hey");
				ps=con.prepareStatement("insert into address(address1,user_id)values(?,?)");
				ps.setString(1, ((List<Object>) employee.get(index)).get(0).toString());
				ps.setInt(2,12);
				ps.executeUpdate();		
				System.out.println("successaddress");  
			} catch (Exception e) {
				e.printStackTrace(); 
			}	
			index++;
		}
		return recordCounter;
	}

	@Override
	public List<Object> getaddress(AddressModel addressPojo) {
		// TODO Auto-generated method stub
		String [] address = addressPojo.getAddress();
		System.out.println("addressPojo : "+ addressPojo);
		System.out.println("In method after array print" + address);
		List<Object> list = new ArrayList<Object>();
		for(int i=0;i<address.length;i++)
		{
			ArrayList<String> customer = new ArrayList <String>();
			customer.add(address[i]);
			list.add(customer);
		}
		System.out.println("list : "+list);
		return list;

	}

}
