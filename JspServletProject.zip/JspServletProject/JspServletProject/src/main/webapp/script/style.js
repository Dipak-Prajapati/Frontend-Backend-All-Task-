/**
 * 
 */
 /*$(document).ready(function(){
			alert("document loaded")
		}) */