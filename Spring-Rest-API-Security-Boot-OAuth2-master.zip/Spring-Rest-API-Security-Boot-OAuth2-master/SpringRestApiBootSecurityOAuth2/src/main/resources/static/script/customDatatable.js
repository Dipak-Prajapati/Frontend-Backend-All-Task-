$(document).ready(function() {
    $('#adminDataTable').DataTable();
} );